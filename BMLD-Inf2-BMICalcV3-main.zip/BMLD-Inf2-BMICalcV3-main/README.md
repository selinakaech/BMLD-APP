# BMLD-Inf2-BMICalcV3
Full blown example of BMI Calculator with user specific login

Link to the app: https://bmi-rechner-v3.streamlit.app
